

-- Playdate screen dimensions
Scr_W, Scr_H = 400,240
