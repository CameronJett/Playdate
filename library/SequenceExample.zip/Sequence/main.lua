import 'CoreLibs/utilities/printer'
import 'CoreLibs/easing'
import 'sequence.lua'

local gfx = playdate.graphics

local _pick_anim_x = sequence.new():from(150):sleep(0.4):to(50, 0.3, "outCirc"):to(0, 0.5, "outExpo"):start()
local _pick_anim_y = sequence.new():from(-240):sleep(0.4):to(0, 0.3, "inQuad"):to(-30, 0.2, "outBack"):to(0, 0.5, "outBounce"):start()

local _pack_anim_x = sequence.new():from(150):sleep(0.2):to(50, 0.3, "outCirc"):to(0, 0.2, "outExpo"):start()
local _pack_anim_y = sequence.new():from(-240):sleep(0.2):to(0, 0.3, "inQuad"):to(-30, 0.2, "outBack"):to(0, 0.5, "outBounce"):start()

local _pup_anim_x = sequence.new()
local _pup_anim_y = sequence.new():from(-240):to(0, 0.5, "outBack"):start()

local _background = gfx.image.new( "files/background" )
local _pick = gfx.image.new( "files/pick" )
local _pack = gfx.image.new( "files/pack" )
local _pup = gfx.image.new( "files/pup" )

function playdate.update()
	sequence.update()

	_background:draw(0,0)
	_pick:draw(100 + _pick_anim_x:get(), _pick_anim_y:get())
	_pack:draw(100 + _pack_anim_x:get(), _pack_anim_y:get())
	_pup:draw(100 + _pup_anim_x:get(), _pup_anim_y:get())

	if playdate.buttonJustPressed(playdate.kButtonA) then
		_pick_anim_x:restart()
		_pick_anim_y:restart()
		_pack_anim_x:restart()
		_pack_anim_y:restart()
		_pup_anim_x:restart()
		_pup_anim_y:restart()
	end
end